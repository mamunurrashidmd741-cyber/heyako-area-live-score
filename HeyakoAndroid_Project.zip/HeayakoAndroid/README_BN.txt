HEYAKO AREA LIVE SCORE — Android Studio Project

এটি একটি প্রাথমিক native Android (Java) অ্যাপ প্রজেক্ট।

খুলতে:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio থেকে Open নির্বাচন করে HeayakoAndroid ফোল্ডারটি খুলুন।
3. Gradle sync শেষ হলে Run চাপুন।
4. APK বানাতে Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।

গুরুত্বপূর্ণ:
- এটি এখন UI/প্রোটোটাইপ; নিরাপদ অ্যাডমিন লগইন বা অনলাইন ডেটাবেজ এখনো যুক্ত নেই।
- স্কোর পরিবর্তন বর্তমানে শুধু অ্যাপের চলতি সেশনে ডেমো হিসেবে দেখা যায়।
- বহু দর্শকের ফোনে একই লাইভ স্কোর দেখাতে Firebase/সমমানের backend, authentication, database rules এবং admin-only permissions যোগ করতে হবে।
- প্রকাশের আগে বাস্তব ডিভাইসে পরীক্ষা, signing এবং নিরাপত্তা যাচাই প্রয়োজন।
