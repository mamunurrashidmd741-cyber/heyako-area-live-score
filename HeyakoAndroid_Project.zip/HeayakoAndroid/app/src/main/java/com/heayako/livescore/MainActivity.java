package com.heayako.livescore;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(7,20,13), panel = Color.rgb(16,35,25), green = Color.rgb(124,255,53), muted = Color.rgb(180,199,184);
    private String homeTeam = "ইসলামপুর এফসি", awayTeam = "হেয়াকো স্পোর্টিং", matchStatus = "লাইভ", scorer = "গোলদাতা: তথ্য যোগ হয়নি";
    private int homeScore = 1, awayScore = 0;
    private LinearLayout root, content;

    @Override public void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); showHome(); }

    private GradientDrawable shape(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); d.setStroke(1, Color.rgb(42,70,49)); return d; }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(2,5,2,5); return t; }
    private Button button(String s, Runnable action) { Button b = new Button(this); b.setText(s); b.setTextColor(bg); b.setAllCaps(false); b.setBackground(shape(green,24)); b.setOnClickListener(v -> action.run()); return b; }
    private void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        TextView head = text("⚽  HEYAKO AREA LIVE SCORE",20,Color.WHITE,true); head.setPadding(18,20,12,16); head.setBackgroundColor(Color.rgb(12,34,19)); root.addView(head);
        TextView sub = text(title,16,green,true); sub.setPadding(18,12,12,8); root.addView(sub);
        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setPadding(16,8,16,24); content.setOrientation(LinearLayout.VERTICAL); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = new LinearLayout(this); nav.setPadding(8,7,8,7); nav.setBackgroundColor(Color.rgb(12,28,18));
        nav.addView(navButton("হোম",this::showHome)); nav.addView(navButton("লাইভ স্কোর",this::showMatches)); nav.addView(navButton("টুর্নামেন্ট",this::showTournaments)); nav.addView(navButton("অ্যাডমিন",this::showAdmin)); root.addView(nav);
        setContentView(root);
    }
    private Button navButton(String s, Runnable r) { Button b=new Button(this); b.setText(s); b.setTextSize(10); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundColor(Color.TRANSPARENT); b.setOnClickListener(v->r.run()); return b; }
    private void card(String title, String body) { LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(15,12,15,12); c.setBackground(shape(panel,18)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=12; content.addView(c,p); c.addView(text(title,17,green,true)); c.addView(text(body,15,Color.WHITE,false)); }
    private void showHome() { base("হোম"); content.addView(text("স্থানীয় ফুটবলের সব আপডেট এক জায়গায়",20,Color.WHITE,true)); content.addView(text("হেয়াকো এলাকার ফুটবল • টুর্নামেন্ট • লাইভ স্কোর",13,muted,false)); card("🔴 বর্তমান ম্যাচ",matchLine()+"\n"+scorer); card("🏆 টুর্নামেন্ট","হেয়াকো এরিয়া স্থানীয় ফুটবল টুর্নামেন্ট\nটুর্নামেন্টের বিস্তারিত শিগগিরই"); card("📢 নোটিশ","নতুন ম্যাচ ও খেলার ঘোষণা এখানে দেখা যাবে।"); }
    private String matchLine(){return homeTeam+"     "+homeScore+" - "+awayScore+"     "+awayTeam+"\nঅবস্থা: "+matchStatus;}
    private void showMatches(){base("লাইভ স্কোর");card("⚽ ম্যাচের স্কোর",matchLine()+"\n"+scorer);card("ম্যাচ তথ্য","গোল, কার্ড ও ম্যাচের সময় অ্যাডমিন আপডেট করবেন।");}
    private void showTournaments(){base("টুর্নামেন্ট");card("🏆 হেয়াকো এরিয়া স্থানীয় ফুটবল টুর্নামেন্ট","দল, ফিক্সচার, ফলাফল ও পয়েন্ট টেবিল এখানে থাকবে।");}
    private void showAdmin(){base("অ্যাডমিন প্যানেল");card("🔐 অ্যাডমিন কন্ট্রোল","এটি এখন UI ডেমো। আসল অ্যাডমিন লগইন ও অনলাইন ডেটাবেজ যুক্ত করার আগে প্রকাশ করবেন না।");content.addView(button("ম্যাচের স্কোর সম্পাদনা",this::editMatch));}
    private void editMatch(){LinearLayout box=new LinearLayout(this);box.setPadding(8,4,8,4);box.setOrientation(LinearLayout.VERTICAL); EditText a=new EditText(this);a.setHint("দল ১");a.setText(homeTeam);EditText b=new EditText(this);b.setHint("দল ২");b.setText(awayTeam);EditText s1=new EditText(this);s1.setHint("দল ১ গোল");s1.setInputType(2);s1.setText(String.valueOf(homeScore));EditText s2=new EditText(this);s2.setHint("দল ২ গোল");s2.setInputType(2);s2.setText(String.valueOf(awayScore));EditText sc=new EditText(this);sc.setHint("গোলদাতার নাম / মিনিট");sc.setText(scorer.equals("গোলদাতা: তথ্য যোগ হয়নি")?"":scorer);EditText st=new EditText(this);st.setHint("ম্যাচের অবস্থা: লাইভ / আসন্ন / শেষ");st.setText(matchStatus);box.addView(a);box.addView(b);box.addView(s1);box.addView(s2);box.addView(sc);box.addView(st);
        new AlertDialog.Builder(this).setTitle("ডেমো স্কোর আপডেট").setView(box).setNegativeButton("বাতিল",null).setPositiveButton("সংরক্ষণ",(d,w)->{homeTeam=a.getText().toString();awayTeam=b.getText().toString();homeScore=parse(s1.getText().toString());awayScore=parse(s2.getText().toString());scorer=sc.getText().toString().isEmpty()?"গোলদাতা: তথ্য যোগ হয়নি":sc.getText().toString();matchStatus=st.getText().toString();Toast.makeText(this,"এই ফোনের ডেমোতে আপডেট হয়েছে",Toast.LENGTH_LONG).show();showAdmin();}).show();}
    private int parse(String s){try{return Math.max(0,Integer.parseInt(s));}catch(Exception e){return 0;}}
}
